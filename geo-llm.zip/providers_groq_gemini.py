# providers_groq_gemini.py
# 统一多 Provider 入口：Groq / Gemini / Grok
import os
import requests
import json
from typing import List, Dict, Any, Optional

# ==============================
#  G R O Q   (免费，超快推理)
# ==============================
class GroqProvider:
    def __init__(self):
        self.api_key = os.getenv("GROQ_API_KEY")
        self.base = "https://api.groq.com/openai/v1"

    def chat(
        self,
        messages: List[Dict[str, str]],
        model: str = "llama-3.3-70b-versatile",
        temperature: float = 0.2,
        max_tokens: Optional[int] = None,
    ) -> str:
        if not self.api_key:
            raise RuntimeError("缺少 GROQ_API_KEY")

        url = f"{self.base}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        data: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            data["max_tokens"] = max_tokens

        resp = requests.post(url, headers=headers, data=json.dumps(data), timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"Groq error: {resp.status_code}, {resp.text}")
        return resp.json()["choices"][0]["message"]["content"]


# ==============================
#  G E M I N I   (免费层)
# ==============================

class GeminiProvider:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.base = "https://generativelanguage.googleapis.com/v1beta/models"

    def chat(
        self,
        text: str,
        model: str = "gemini-2.5-flash",
        temperature: float = 0.2,
        max_output_tokens: Optional[int] = None,
    ) -> str:
        if not self.api_key:
            raise RuntimeError("缺少 GEMINI_API_KEY")

        url = f"{self.base}/{model}:generateContent?key={self.api_key}"
        headers = {"Content-Type": "application/json"}
        data: Dict[str, Any] = {
            "contents": [{"parts": [{"text": text}]}],
            "generationConfig": {"temperature": temperature},
        }
        if max_output_tokens is not None:
            data["generationConfig"]["maxOutputTokens"] = max_output_tokens

        resp = requests.post(url, headers=headers, data=json.dumps(data), timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"Gemini error: {resp.status_code}, {resp.text}")
        return resp.json()["candidates"][0]["content"]["parts"][0]["text"]


# ==============================
#  G R O K  (xAI, OpenAI-compatible)
# ==============================

class GrokProvider:
    def __init__(self):
        self.api_key = os.getenv("GROK_API_KEY") or os.getenv("XAI_API_KEY")
        self.base = os.getenv("GROK_BASE_URL", "https://api.x.ai/v1")

    def chat(
        self,
        messages: List[Dict[str, str]],
        model: str = "grok-2-latest",
        temperature: float = 0.2,
        max_tokens: Optional[int] = None,
    ) -> str:
        if not self.api_key:
            raise RuntimeError("缺少 GROK_API_KEY 或 XAI_API_KEY")

        url = f"{self.base}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        data: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            data["max_tokens"] = max_tokens

        resp = requests.post(url, headers=headers, data=json.dumps(data), timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"Grok error: {resp.status_code}, {resp.text}")
        return resp.json()["choices"][0]["message"]["content"]


# =====================================
#   Provider Registry（统一模型入口）
# =====================================

class ModelHub:
    def __init__(self):
        self.groq = GroqProvider()
        self.gemini = GeminiProvider()
        self.grok = GrokProvider()

    def run(self, provider: str, prompt: str, **kw) -> str:
        """
        provider: "groq" | "gemini" | "grok"
        """
        p = (provider or "").lower().strip()

        if p == "groq":
            return self.groq.chat(
                messages=[{"role": "user", "content": prompt}],
                **kw
            )
        if p == "gemini":
            return self.gemini.chat(prompt, **kw)
        if p == "grok":
            return self.grok.chat(
                messages=[{"role": "user", "content": prompt}],
                **kw
            )

        raise RuntimeError(f"Unknown provider: {provider}")
