# app.py — GEO-Max 多模型文本优化引擎（Groq/Gemini 可切换 · 带日志）
import os
import re
import time
import tempfile
import traceback
from pathlib import Path
from typing import Dict, Any, List, Optional

import json  # ✅ 新增
import logging
import gradio as gr


# =========================
# ★ 修复 Gradio JSON Schema 里 bool 导致的 APIInfoParseError
# =========================
try:
    # 一些 Gradio 版本在解析 Blocks 的 JSON Schema 时，
    # 会把 additionalProperties=True 直接丢给
    # gradio_client.utils._json_schema_to_python_type(True, defs)
    # 然后抛出：APIInfoParseError("Cannot parse schema True")
    import gradio_client.utils as gc_utils  # type: ignore

    _orig_json_schema_to_python_type = gc_utils._json_schema_to_python_type  # type: ignore[attr-defined]

    def _safe_json_schema_to_python_type(schema, defs=None):
        # 如果 schema 本身是布尔值（True / False），这里直接认为是 "Any" 类型，
        # 避免抛出 APIInfoParseError。
        if isinstance(schema, bool):
            return "Any"
        return _orig_json_schema_to_python_type(schema, defs)

    gc_utils._json_schema_to_python_type = _safe_json_schema_to_python_type  # type: ignore[attr-defined]
    logging.info("✔ Patched gradio_client.utils._json_schema_to_python_type for bool schema.")
except Exception as e:
    logging.warning(f"⚠ Failed to patch gradio_client.utils._json_schema_to_python_type: {e}")

# =========================
# 业务模块导入
# =========================
from geo_logger import log_run
from geo_evaluator import evaluate_geo_score
from geo_report import render_report_html
from geo_impression import (
    impression_word_count,
    impression_pos_count,
    impression_wordpos_count,
    compute_delta,
)
from pipeline.inference_engine import call_model

# =========================
# 日志设置
# =========================
LOG_PATH = Path(__file__).with_name("geo_ui_debug.log")
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOG_PATH, encoding="utf-8"),
    ],
)
logger = logging.getLogger("geo-ui")

logger.info("=== GEO-Max UI 启动 ===")
logger.info("Env check: GROQ_API_KEY set? %s",
            "YES" if os.getenv("GROQ_API_KEY") else "NO")
logger.info("Env check: GEMINI_API_KEY set? %s",
            "YES" if os.getenv("GEMINI_API_KEY") else "NO")


# =========================
# Prompt 配置加载（使用 geo_prompts.json · 版本2）
# =========================

# 默认兜底的中文 GEO-Max Prompt（当 geo_prompts.json 读取失败时使用）
DEFAULT_GEO_PROMPT_ZH = """
你是一名生成式引擎优化（GEO）专家，负责将下面的文本改写为更适合被大模型引用和总结的版本。请遵守以下规则：

1. 在不歪曲原意的前提下，提升逻辑清晰度与可读性；
2. 保留对“事实、时间、数据、专有名词、机构名称”等关键信息的准确表述；
3. 避免口语化和过度修辞，保持专业、克制、可靠的语气；
4. 如果原文逻辑存在缺口，可以通过“补足上下文衔接语”的方式弱化断裂感，但不要凭空杜撰事实；
5. 不要输出任何额外解释，只输出一版改写后的正文内容。

下面是需要改写的原文：

{TEXT}
""".strip()

GEO_PROMPTS: Dict[str, str] = {}

def _load_geo_prompts() -> None:
    """从 geo_prompts.json 读取 Prompt 模板。"""
    global GEO_PROMPTS
    prompt_file = Path(__file__).with_name("geo_prompts.json")
    try:
        if prompt_file.exists():
            GEO_PROMPTS = json.loads(prompt_file.read_text(encoding="utf-8"))
            logger.info("geo_prompts.json 加载成功，包含键：%s", list(GEO_PROMPTS.keys()))
        else:
            GEO_PROMPTS = {}
            logger.warning("geo_prompts.json 未找到，使用内置 DEFAULT_GEO_PROMPT_ZH 兜底。")
    except Exception as e:
        GEO_PROMPTS = {}
        logger.error("加载 geo_prompts.json 失败，将使用默认 Prompt：%s", e)

def build_geo_prompt(text: str, lang_instruction: str = "") -> str:
    """
    基于 geo_prompts.json 生成完整 Prompt。
    - 优先使用 geo_prompts.json 中的 'geo_max_zh' 模板；
    - 若读取失败，回退到 DEFAULT_GEO_PROMPT_ZH；
    - 将 {TEXT} 替换为待改写文本；
    - 若有 lang_instruction（语言要求），追加在末尾。
    """
    # 1) 选择模板
    tpl = GEO_PROMPTS.get("geo_max_zh") or DEFAULT_GEO_PROMPT_ZH

    # 2) 填充 {TEXT}
    try:
        prompt = tpl.format(TEXT=text)
    except Exception as e:
        logger.warning("geo_prompts.json 模板 format 失败：%s，改用简单拼接方式。", e)
        prompt = tpl + "\n\n【原文】\n" + text

    # 3) 附加语言指令
    lang_instruction = (lang_instruction or "").strip()
    if lang_instruction:
        prompt += "\n\n" + lang_instruction

    return prompt

# 模块加载时，预先读取一次 geo_prompts.json
_load_geo_prompts()


# =========================
# UI 常量
# =========================
APP_THEME = gr.themes.Soft()
APP_CSS = """
#wrap{max-width:1280px;margin:0 auto}
.tile{border:1px solid #eee;padding:14px;border-radius:12px}
.stack>*{margin-bottom:10px}
.tabs button{font-weight:600}
.footnote{font-size:12px;opacity:.7}
"""

# Provider 映射（UI显示名 -> inference provider key）
PROVIDER_MAP = {
    "Groq": "groq",
    "Gemini": "gemini",
    # 预留，暂不接入：
    "Grok": "groq",
    "通义千问": "qwen",
    "DeepSeek": "deepseek",
    "文心一言": "qwen",
}

# 默认模型
DEFAULT_MODELS = {
    "groq": "llama-3.3-70b-versatile",
    "gemini": "gemini-2.5-pro",
    "qwen": "qwen-turbo",
    "deepseek": "deepseek-chat",
}


def norm_provider(ui_name: str) -> str:
    p = PROVIDER_MAP.get(ui_name, "groq")
    logger.debug("norm_provider: ui=%s -> provider=%s", ui_name, p)
    return p


def safe_progress(progress, v: float, desc: str = ""):
    try:
        progress(v, desc=desc)
    except Exception:
        # 有时候 gradio progress 在某些环境下会抛错，这里直接忽略
        pass


def _retry_call(fn, times=2, sleep_s=0.4):
    last = None
    for i in range(max(1, times)):
        try:
            logger.debug("retry_call: try %d/%d", i + 1, times)
            return fn()
        except Exception as e:
            last = e
            logger.warning("retry_call error: %s", e)
            time.sleep(sleep_s)
    if last:
        raise last


# =========================
# 工具函数：分块
# =========================
def split_into_chunks(text: str, max_chars: int) -> List[str]:
    text = text.strip()
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]

    paras = re.split(r"\n{2,}", text)
    chunks, buf = [], ""
    for p in paras:
        if len(buf) + len(p) + 2 <= max_chars:
            buf = (buf + "\n\n" + p).strip()
        else:
            if buf:
                chunks.append(buf)
            buf = p.strip()
    if buf:
        chunks.append(buf)

    logger.debug("split_into_chunks: %d chunks", len(chunks))
    return chunks

def _build_lang_instruction(out_lang: str) -> str:
    """
    根据下拉框选择，生成给大模型看的“输出语言要求”说明。
    """
    if out_lang == "Chinese":
        return "请使用简体中文输出结果。"
    if out_lang == "English":
        return "Please answer in English."
    # Auto 或其他情况
    return "输出语言请与输入文本的主要语言保持一致。"


# =========================
# Tab1：GEO-Max 优化 + 评分
# =========================
def run_geo(
    text: str,
    model_ui: str,
    use_chunk: bool,
    max_chars: int,
    out_lang: str = "Auto",
    progress=gr.Progress(),
):

    logger.info("run_geo called, model_ui=%s, use_chunk=%s, max_chars=%s",
                model_ui, use_chunk, max_chars)
    provider = norm_provider(model_ui)
    model = DEFAULT_MODELS.get(provider)

    safe_progress(progress, 0.05, "准备输入")

    if not text or not text.strip():
        return "⚠️ 请输入原文。", text

    try:
        # 根据下拉框选择构造“输出语言要求”
        lang_instruction = _build_lang_instruction(out_lang)

        chunks = split_into_chunks(text, max_chars) if use_chunk else [text]
        safe_progress(progress, 0.20, f"分块完成：{len(chunks)} 块")

        outs = []
        for i, ck in enumerate(chunks, 1):
            safe_progress(
                progress,
                0.20 + 0.60 * i / len(chunks),
                f"调用模型处理第 {i}/{len(chunks)} 块",
            )
            prompt = f"""你是一名生成式引擎优化（GEO）专家，请对下面内容进行综合优化：
- 保持原意
- 增强权威性与可引用性
- 适当增加数据与术语解释
- 结构更清晰，可被AI总结引用

原文：
{ck}
"""
            logger.debug("run_geo: calling model provider=%s model=%s", provider, model)
            out = call_model(
                prompt,
                provider=provider,
                model=model,
                temperature=0.2,
            )
            outs.append((out or "").strip())

        final = "\n\n".join(outs).strip()
        safe_progress(progress, 0.95, "完成")
        logger.info("run_geo finished, length=%d", len(final))
        return final, text

    except Exception as e:
        logger.error("run_geo exception: %s", e)
        traceback.print_exc()
        # 前端直接显示错误信息，避免只看到红色 Error
        msg = f"⚠️ run_geo 出错：{type(e).__name__} - {e}"
        return msg, text


def run_score(src_text: str, opt_text: str, model_ui: str):
    logger.info("run_score called, model_ui=%s", model_ui)
    provider = norm_provider(model_ui)
    model = DEFAULT_MODELS.get(provider)

    if not src_text.strip() or not opt_text.strip():
        return "⚠️ 缺少文本，无法评分。", {}

    try:
        score_json = evaluate_geo_score(
            model,
            query="",
            src_text=src_text,
            opt_text=opt_text,
            mode="single_text",
            samples=1,
            provider=provider,  # 你已在 geo_evaluator 里加了这个参数
        )

        logger.debug("run_score: score_json=%s", score_json)

        md = f"""
**GEO-Score：{score_json["geo_score"]:.1f}/100**

- Relevance：{score_json["relevance"]:.2f}
- Influence：{score_json["influence"]:.2f}
- Uniqueness：{score_json["uniqueness"]:.2f}
- Diversity：{score_json["diversity"]:.2f}
- Subjective Position：{score_json["subjective_position"]:.2f}
- Subjective Count：{score_json["subjective_count"]:.2f}
- Follow Up：{score_json["follow_up"]:.2f}

Objective Bonus：
- Compression Ratio：{score_json["objective"]["compression_ratio"]:.3f}
- TTR：{score_json["objective"]["ttr"]:.3f}
- Reading Ease：{score_json["objective"]["reading_ease"]:.1f}
"""
        return md, score_json
    except Exception as e:
        logger.error("run_score exception: %s", e)
        traceback.print_exc()
        return f"⚠️ 评分失败：{type(e).__name__} - {e}", {}


def export_html_with_score(src_text: str, opt_text: str, score_json: Dict[str, Any]):
    logger.info("export_html_with_score called")
    if not score_json:
        return None, "⚠️ 请先计算分数。"
    try:
        html = render_report_html(opt_text, score_json)
        tmpdir = tempfile.gettempdir()
        path = os.path.join(tmpdir, "geo_report.html")
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        logger.info("report exported to %s", path)
        return path, "✅ 已导出 HTML 报告。"
    except Exception as e:
        logger.error("export_html_with_score exception: %s", e)
        traceback.print_exc()
        return None, f"⚠️ 导出失败：{type(e).__name__} - {e}"


# =========================
# Tab2：Impression
# =========================
def run_impression_single(answer: str, n_sources: int, mode_sel: str):
    logger.info("run_impression_single called, mode=%s", mode_sel)
    try:
        if mode_sel == "WordPos":
            dist = impression_wordpos_count(answer, int(n_sources))
        elif mode_sel == "Word":
            dist = impression_word_count(answer, int(n_sources))
        else:
            dist = impression_pos_count(answer, int(n_sources))
        return "✅ 计算完成", dist
    except Exception as e:
        logger.error("run_impression_single exception: %s", e)
        traceback.print_exc()
        return f"⚠️ 失败：{type(e).__name__} - {e}", {}


def run_impression_delta(
    before: str,
    after: str,
    n_sources: int,
    target_idx: int,
    mode_sel: str,
):
    logger.info("run_impression_delta called, mode=%s", mode_sel)
    try:
        if mode_sel == "WordPos":
            res = compute_delta(
                before, after, int(n_sources), int(target_idx), mode="wordpos"
            )
        elif mode_sel == "Word":
            res = compute_delta(
                before, after, int(n_sources), int(target_idx), mode="word"
            )
        else:
            res = compute_delta(
                before, after, int(n_sources), int(target_idx), mode="pos"
            )
        return "✅ 计算完成", res
    except Exception as e:
        logger.error("run_impression_delta exception: %s", e)
        traceback.print_exc()
        return f"⚠️ 失败：{type(e).__name__} - {e}", {}


# =========================
# Tab3：GEO-CoT 两段式 Markdown
# =========================
def geo_cot_model_call(prompt: str, model_ui: str):
    provider = norm_provider(model_ui)
    model = DEFAULT_MODELS.get(provider)
    logger.debug("geo_cot_model_call: provider=%s model=%s", provider, model)
    return call_model(prompt, provider=provider, model=model, temperature=0.2)


def _load_md_template(name: str) -> str:
    base = os.path.join(os.path.dirname(__file__), "geo_prompts")
    path = os.path.join(base, f"{name}.md")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        logger.error("load_md_template error: %s", e)
        return f"⚠️ 无法读取模板：{path}\n\n错误：{e}"


_ALLOWED_MD_KEYS = {"USER_QUESTION", "BRAND_BRIEF", "MUST_EXPOSE", "EXPO_HINT", "STAGE1_MD"}


def _fmt_md_template(tpl: str, **vars) -> str:
    if not isinstance(tpl, str):
        tpl = str(tpl or "")
    t = tpl.replace("{", "{{").replace("}", "}}")
    for key in _ALLOWED_MD_KEYS:
        t = t.replace("{{" + key + "}}", "{" + key + "}")
    return t.format(**vars)


def _save_md_to_file(md_text: str, filename: str):
    try:
        tmpdir = tempfile.gettempdir()
        path = os.path.join(tmpdir, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(md_text or "")
        logger.info("md saved to %s", path)
        return path
    except Exception as e:
        logger.error("save_md_to_file error: %s", e)
        return None


def run_stage1_markdown(q: str, brand_ctx: str, expo: str, model_ui: str, progress=gr.Progress()):
    logger.info("run_stage1_markdown called, model_ui=%s", model_ui)
    safe_progress(progress, 0.10, "加载 Stage1 模板")
    tpl = _load_md_template("cot_stage1")
    if tpl.startswith("⚠️ 无法读取模板"):
        return tpl, "", None, "⚠️ 模板未找到"

    try:
        safe_progress(progress, 0.25, "渲染 Stage1 提示词")
        prompt = _fmt_md_template(
            tpl,
            USER_QUESTION=(q or "").strip(),
            BRAND_BRIEF=(brand_ctx or "").strip(),
            MUST_EXPOSE=(expo or "").strip(),
            EXPO_HINT="",
        )

        safe_progress(progress, 0.60, "请求模型 Stage1")
        out_md = _retry_call(lambda: geo_cot_model_call(prompt, model_ui), times=2) or ""
        if not out_md.strip():
            out_md = "⚠️ 模型未返回内容，请重试。"

        dl_path = _save_md_to_file(out_md, "geo_stage1_output.md")
        safe_progress(progress, 0.95, "完成")
        return out_md, prompt[:1200], dl_path, "✅ Stage1 完成：可编辑后进入 Stage2。"
    except Exception as e:
        logger.error("run_stage1_markdown exception: %s", e)
        traceback.print_exc()
        return f"> ⚠️ Stage1 出错：{type(e).__name__} - {e}", "", None, "⚠️ 执行失败"


def run_stage2_markdown(
    q: str,
    brand_ctx: str,
    expo: str,
    model_ui: str,
    stage1_md: str,
    progress=gr.Progress(),
):
    logger.info("run_stage2_markdown called, model_ui=%s", model_ui)
    safe_progress(progress, 0.10, "加载 Stage2 模板")
    tpl = _load_md_template("cot_stage2")
    if tpl.startswith("⚠️ 无法读取模板"):
        return "> ⚠️ 无法读取 Stage2 模板。", "", None, "⚠️ 模板未找到"

    try:
        safe_progress(progress, 0.30, "渲染 Stage2 提示词")
        prompt = _fmt_md_template(
            tpl,
            USER_QUESTION=(q or "").strip(),
            BRAND_BRIEF=(brand_ctx or "").strip(),
            MUST_EXPOSE=(expo or "").strip(),
            EXPO_HINT="",
            STAGE1_MD=stage1_md or "",
        )

        safe_progress(progress, 0.65, "请求模型 Stage2")
        out_md = _retry_call(lambda: geo_cot_model_call(prompt, model_ui), times=2) or ""
        if not out_md.strip():
            out_md = "> ⚠️ Stage2 未产出内容，请检查 Stage1 文档或模板语法。"

        dl_path = _save_md_to_file(out_md, "geo_stage2_output.md")
        safe_progress(progress, 0.95, "完成")
        return out_md, prompt[:1200], dl_path, "✅ Stage2 完成：右侧可复制/下载。"
    except Exception as e:
        logger.error("run_stage2_markdown exception: %s", e)
        traceback.print_exc()
        return f"> ⚠️ Stage2 出错：{type(e).__name__} - {e}", "", None, "⚠️ 执行失败"


# =========================
# Gradio UI
# =========================
with gr.Blocks(
    title="GEO-Max 多模型文本优化引擎（含评分）",
    analytics_enabled=False,
    theme=APP_THEME,
    css=APP_CSS,
) as demo:
    with gr.Group(elem_id="wrap"):
        gr.Markdown("### GEO-Max · 生成式引擎优化\n极简、稳定：内容改写 + 自动评分。")

        with gr.Tabs(elem_classes=["tabs"]):
            # ---- Tab 1 ----
            with gr.Tab("⚙️ 产品模式（质量评分）"):
                with gr.Row():
                    with gr.Column(scale=1, elem_classes=["stack"]):
                        with gr.Group(elem_classes=["tile"]):
                            inp_text = gr.Textbox(label="✍️ 输入原文", lines=8, show_copy_button=True)
                            model_dd = gr.Dropdown(
                                choices=["Groq", "Gemini", "Grok", "通义千问", "DeepSeek", "文心一言"],
                                value="Groq",
                                label="🧩 选择模型",
                            )
                            # 🌐 输出语言选择
                            lang_dd = gr.Dropdown(
                                choices=["Auto", "Chinese", "English"],
                                value="Auto",
                                label="🌐 Output language",
                            )
                            use_chunk = gr.Checkbox(value=True, label="自动分块（建议开启）")
                            max_chars = gr.Slider(800, 6000, value=2400, step=200, label="单次最大字符数")

                            btn_run = gr.Button("🚀 生成 GEO-Max 优化稿", variant="primary")
                            btn_clear = gr.Button("🧹 清空")
                            gr.Markdown("<div class='footnote'>提示：我们不保存你的文本；评分仅在本地会话内计算。</div>")

                    with gr.Column(scale=1, elem_classes=["stack"]):
                        with gr.Group(elem_classes=["tile"]):
                            out_text = gr.Textbox(
                                label="📈 GEO-Max 优化结果",
                                lines=12,
                                show_copy_button=True,
                            )
                            btn_score = gr.Button("📊 计算 GEO-Score（自动评分）")
                            score_md = gr.Markdown("")
                            with gr.Row():
                                btn_html = gr.Button("导出带评分报告（HTML）")
                                file_html = gr.File(label="下载报告", visible=False)
                            tip = gr.Markdown("")

                state_original = gr.State("")
                state_optimized = gr.State("")
                state_score = gr.State({})

                btn_run.click(
                    fn=run_geo,
                    inputs=[inp_text, model_dd, use_chunk, max_chars, lang_dd],
                    outputs=[out_text, state_original],
                    queue=False,
                )

                out_text.change(
                    lambda x: x,
                    inputs=out_text,
                    outputs=state_optimized,
                    queue=False,
                )
                btn_score.click(
                    fn=run_score,
                    inputs=[state_original, state_optimized, model_dd],
                    outputs=[score_md, state_score],
                    queue=False,
                )
                btn_html.click(
                    fn=export_html_with_score,
                    inputs=[state_original, state_optimized, state_score],
                    outputs=[file_html, tip],
                    queue=False,
                )
                btn_clear.click(
                    lambda: ("", "", "", "", None),
                    None,
                    [inp_text, out_text, score_md, tip, file_html],
                    queue=False,
                )

            # ---- Tab 2 ----
            with gr.Tab("📘 论文模式（with citations）"):
                with gr.Row():
                    with gr.Column(scale=1, elem_classes=["stack"]):
                        with gr.Group(elem_classes=["tile"]):
                            n_sources = gr.Number(value=3, label="来源总数（N）", precision=0)
                            mode_sel = gr.Dropdown(
                                choices=["WordPos", "Word", "Pos"],
                                value="WordPos",
                                label="指标模式",
                            )
                            answer_once = gr.Textbox(
                                label="单次分布：带 [1][2]… 的答案（任一段）",
                                lines=6,
                                show_copy_button=True,
                            )
                            btn_once = gr.Button("📊 计算单次分布", variant="secondary")
                            msg_once = gr.Markdown("")
                            dist_once = gr.JSON(label="分布（和=1）")
                    with gr.Column(scale=1, elem_classes=["stack"]):
                        with gr.Group(elem_classes=["tile"]):
                            before_ans = gr.Textbox(
                                label="Before：带引用的答案",
                                lines=6,
                                show_copy_button=True,
                            )
                            after_ans = gr.Textbox(
                                label="After：带引用的答案",
                                lines=6,
                                show_copy_button=True,
                            )
                            target_idx = gr.Number(value=1, label="目标来源索引（1..N）", precision=0)
                            btn_delta = gr.Button("📈 计算 Δ 提升（After - Before）", variant="primary")
                            msg_delta = gr.Markdown("")
                            res_delta = gr.JSON(label="结果（含 dist_before / dist_after / delta）")

                btn_once.click(
                    fn=run_impression_single,
                    inputs=[answer_once, n_sources, mode_sel],
                    outputs=[msg_once, dist_once],
                    queue=False,
                )
                btn_delta.click(
                    fn=run_impression_delta,
                    inputs=[before_ans, after_ans, n_sources, target_idx, mode_sel],
                    outputs=[msg_delta, res_delta],
                    queue=False,
                )

            # ---- Tab 3 ----
            with gr.Tab("🧠 GEO-CoT（两段式·Markdown 模板）"):
                with gr.Row():
                    with gr.Column(scale=1, elem_classes=["stack"]):
                        with gr.Group(elem_classes=["tile"]):
                            md_q = gr.Textbox(label="🎯 目标问题", placeholder="例如：推荐几家××品牌", lines=2)
                            md_brand = gr.Textbox(label="🏷️ 甲方资料（文字）", lines=6)
                            md_expo = gr.Textbox(
                                label="🔗 期望露出（逗号分隔）",
                                placeholder="品牌名, 官网链接, 指定词组",
                                lines=2,
                            )
                            md_model = gr.Dropdown(
                                choices=["Groq", "Gemini", "Grok", "DeepSeek", "通义千问", "文心一言"],
                                value="Groq",
                                label="🧩 模型",
                            )

                        with gr.Group(elem_classes=["tile"]):
                            gr.Markdown("#### Stage 1：执行 `cot_stage1.md` → 生成 Markdown（可编辑）")
                            btn_s1 = gr.Button("🚀 运行 Stage 1（Markdown）", variant="primary")
                            s1_md_editable = gr.Textbox(
                                label="📝 Stage1 产出（可编辑 Markdown）",
                                lines=18,
                                show_copy_button=True,
                            )
                            s1_prompt_dbg = gr.Textbox(
                                label="调试：Stage1 最终提示词片段（只读）",
                                lines=5,
                                interactive=False,
                            )
                            s1_download = gr.DownloadButton(label="下载 Stage1 .md", value=None)
                            s1_tip = gr.Markdown("")
                            btn_confirm_s2 = gr.Button(
                                "✅ 使用上方 Markdown 进入 Stage 2",
                                variant="secondary",
                            )

                    with gr.Column(scale=1, elem_classes=["stack"]):
                        with gr.Group(elem_classes=["tile"]):
                            gr.Markdown("#### Stage 2：执行 `cot_stage2.md`（注入你编辑后的 Stage1 文档）")
                            s2_md_view = gr.Markdown(value="> 运行 Stage 2 后，这里显示最终 Markdown")
                            s2_prompt_dbg = gr.Textbox(
                                label="调试：Stage2 最终提示词片段（只读）",
                                lines=5,
                                interactive=False,
                            )
                            s2_download = gr.DownloadButton(label="下载 Stage2 .md", value=None)
                            s2_tip = gr.Markdown("")

                btn_s1.click(
                    run_stage1_markdown,
                    inputs=[md_q, md_brand, md_expo, md_model],
                    outputs=[s1_md_editable, s1_prompt_dbg, s1_download, s1_tip],
                    show_progress=True,
                )

                btn_confirm_s2.click(
                    run_stage2_markdown,
                    inputs=[md_q, md_brand, md_expo, md_model, s1_md_editable],
                    outputs=[s2_md_view, s2_prompt_dbg, s2_download, s2_tip],
                    show_progress=True,
                )

if __name__ == "__main__":
    demo.launch(
        server_name="0.0.0.0",
        server_port=int(os.getenv("GRADIO_SERVER_PORT", "7860")),
    )
